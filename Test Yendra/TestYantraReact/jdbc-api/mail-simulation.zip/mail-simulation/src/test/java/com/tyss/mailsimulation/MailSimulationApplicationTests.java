package com.tyss.mailsimulation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailSimulationApplicationTests {

	@Test
	void contextLoads() {
	}

}
