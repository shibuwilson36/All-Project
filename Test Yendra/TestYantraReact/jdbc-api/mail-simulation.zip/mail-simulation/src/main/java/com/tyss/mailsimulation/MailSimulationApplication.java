package com.tyss.mailsimulation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailSimulationApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailSimulationApplication.class, args);
	}

}
